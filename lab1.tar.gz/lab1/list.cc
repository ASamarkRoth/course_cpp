#include <iostream>
#include "list.h"

List::List() {
}

List::~List() {
}

bool List::exists(int d) const {
	return true;
}

int List::size() const {
	return 0;
}

bool List::empty() const {
	return true;
}

void List::insertFirst(int d) {
}

void List::remove(int d, DeleteFlag df) {
}

void List::print() const {
}

